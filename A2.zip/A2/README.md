# CS 488 - Assignment 2
# Jacob Bush - 20558637

## Compilation
This program is compiled in the usual way.

Run
```sh
premake4 gmake
make
./A2
```
in the `/A2` directory.

## Manual
This assignment was completed to be in line with the assignment specifications.

## Assumptions
	- Moving mouse right is positive manipulation. For instance, moving the mouse to the right while in Translate Model interaction mode will move the model towards the positive end of the axis. Moving the mouse to the right will rotate clockwise. Moving the mouse to the right will scale up.
