# CS488 A0
 
 ---

## Compilation
Run
```sh
premake4 gmake
make
./A0
```
in `/A0`.

## Manual
This section would contain information about the assignment
