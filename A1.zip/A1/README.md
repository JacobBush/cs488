# CS 488 - Assignment 1
# Jacob Bush - 20558637

## Compilation
This program is compiled in the usual way.

Run
```sh
premake4 gmake
make
./A1
```
in the `/A1` directory.

## Manual
This assignment was completed to be in line with the assignment specifications.

### Extra Feature
Clicking on the "Extra Feature: Toggle Gradient Stacks" button will remove the specified
colors from all stacks and color the stacks in a gradient that changes depending on
the height of the stack. Clicking the button again returns to the original colors.
